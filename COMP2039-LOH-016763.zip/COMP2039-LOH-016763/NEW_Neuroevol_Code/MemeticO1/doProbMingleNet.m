% Basic cross-over operator
function pmSols = doProbMingleNet(sols,memParams)

if memParams.probMingleType == 1
    pmSols = doProbMingleNet1(sols,memParams);
else
    pmSols = doProbMingleNet1(sols,memParams);
end
    
end

