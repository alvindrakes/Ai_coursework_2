function ccInfo = compCCinfo2Net(sols,numPat)
% Extract basic information
% errPats = getErrPatsNet(sols);
% numSols = size(sols,2);

disp('[12/03/13] Currently, not implemented.');



end

