function val = simpleGauss(x,width)

val = exp(-(x^2)/width);


end

