function outVal = revPutInRange(inVal,minVal,maxVal)
bigDiff = maxVal-minVal;
smallDiff = inVal-minVal;
outVal = smallDiff/bigDiff;


end

