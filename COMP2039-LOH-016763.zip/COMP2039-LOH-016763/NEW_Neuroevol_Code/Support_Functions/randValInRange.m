function aVal = randValInRange(minVal,maxVal)

diff = maxVal - minVal;
aVal = minVal + rand*diff;

end

