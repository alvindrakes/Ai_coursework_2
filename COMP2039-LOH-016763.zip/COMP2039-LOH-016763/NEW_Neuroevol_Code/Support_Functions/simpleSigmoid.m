function val = simpleSigmoid(x,steepness)

val = 1/(1+exp(-x*steepness));


end

